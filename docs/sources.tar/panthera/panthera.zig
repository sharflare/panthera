//! # Panthera
//! ### Lightning fast SIMD-accelerated serializer/deserializer framework.
//!
//! Like serde, panthera exposes a unified frontend for multiple format backends.
//! Each backend (json, yaml, ...) implements the same API:
//! `parseValue`, `parseFromSlice`, `parseFree`, and `stringify`.
//!
//! ## Extensibility
//!
//! The shared infrastructure (`types`, `format`, `simd`, `dragonbox`) and the
//! backend protocol (`backend`) are stable public API. Anyone can write a custom
//! backend as a standalone Zig module -- see `panthera.backend` for details.
//!
//! ## Format-specific API
//!
//! ```zig
//! const cfg  = try panthera.json.parseFromSlice(Config, allocator, json_str, .{});
//! const cfg2 = try panthera.yaml.parseFromSlice(Config, allocator, yaml_str, .{});
//! ```
//!
//! ## Runtime format detection
//!
//! ```zig
//! const fmt = panthera.backend.detectFormat(path) orelse return error.UnknownFormat;
//! return panthera.backend.parseFromSlice(T, fmt, allocator, input, .{});
//! ```
//!
//! ## Backwards-compatible JSON shortcut
//!
//! The root module also re-exports the JSON backend directly:
//!
//! ```zig
//! const cfg = try panthera.parseFromSlice(Config, allocator, json_str, .{});
//! ```

const std = @import("std");

const types = @import("types.zig");

// --- Backend protocol & registry ---

pub const backend = @import("backend.zig");

// --- Shared infrastructure (stable public API) ---

pub const types_mod = types;
pub const format = @import("format.zig");
pub const simd = @import("simd.zig");
pub const dragonbox = @import("dragonbox.zig");

// --- Shared types (re-exported for convenience) ---

pub const Value = types.Value;
pub const Error = types.Error;
pub const ParseOptions = types.ParseOptions;
pub const StringifyOptions = types.StringifyOptions;
pub const ObjectMap = types.ObjectMap;
pub const Array = types.Array;
pub const MAX_DEPTH = types.MAX_DEPTH;
pub const MAX_TOKEN_LEN = types.MAX_TOKEN_LEN;
pub const MAX_INPUT_BYTES = types.MAX_INPUT_BYTES;
pub const ParseResult = types.ParseResult;

// --- Convenience re-exports of SIMD helpers ---

pub const simdParseU64Decimal = @import("simd.zig").simdParseU64Decimal;
pub const SpaceScanner = @import("simd.zig").SpaceScanner;

// --- Built-in format backends ---

pub const json = @import("spec/json/root.zig");
pub const yaml = @import("spec/yaml/root.zig");
pub const kdl = @import("spec/kdl/root.zig");
pub const xml = @import("spec/xml/root.zig");
pub const toml = @import("spec/toml/root.zig");

// --- Back Compat (JSON shortcuts) ---

pub const parseValue = json.parseValue;
pub const parseFromSlice = json.parseFromSlice;
pub const parseFree = json.parseFree;
pub const parse = json.parse;
pub const stringify = json.stringify;
pub const decodeString = json.decodeString;

pub const Tokenizer = json.Tokenizer;
pub const TokenTag = json.TokenTag;
pub const Token = json.Token;

// --- Tests ---

test {
    _ = @import("tests/json.zig");
}
test {
    _ = @import("tests/yaml.zig");
}
test {
    _ = @import("tests/kdl.zig");
}
test {
    _ = @import("tests/xml.zig");
}
test {
    _ = @import("tests/toml.zig");
}

test "skipWhitespace: all" {
    var sc = SpaceScanner.init();
    try std.testing.expectEqual(@as(usize, 6), sc.nextNonSpace("   \t\n\r", 0));
}

test "skipWhitespace: mixed" {
    var sc = SpaceScanner.init();
    try std.testing.expectEqual(@as(usize, 2), sc.nextNonSpace("  hello", 0));
}
