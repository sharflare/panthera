//! Parse and serialize TOML.
//!
//! # Usage
//!
//! ## Dynamic value tree
//! ```zig
//! const std = @import("std");
//! const toml = @import("panthera").toml;
//!
//! pub fn main() !void {
//!     const input =
//!         \\title = "TOML Example"
//!         \\[owner]
//!         \\name = "Alice"
//!     ;
//!
//!     var result = try toml.parseValue(std.heap.page_allocator, input);
//!     defer result.deinit();
//!     std.debug.print("title: {s}\n", .{result.value.object.get("title").?.string});
//! }
//! ```
//!
//! ## Struct deserialization
//! ```zig
//! const std = @import("std");
//! const toml = @import("panthera").toml;
//!
//! const Config = struct {
//!     title: []const u8,
//!     owner: Owner,
//!
//!     const Owner = struct {
//!         name: []const u8,
//!         age: u32,
//!     };
//! };
//!
//! pub fn main() !void {
//!     const input =
//!         \\title = "TOML Example"
//!         \\[owner]
//!         \\name = "Alice"
//!         \\age = 30
//!     ;
//!
//!     var result = try toml.parseFromSlice(Config, std.heap.page_allocator, input, .{});
//!     defer result.deinit();
//!     std.debug.print("title: {s}, owner: {s}\n", .{ result.value.title, result.value.owner.name });
//! }
//! ```
//!
//! ## Stringify back to TOML
//! ```zig
//! const std = @import("std");
//! const toml = @import("panthera").toml;
//!
//! pub fn main() !void {
//!     var buf: [512]u8 = undefined;
//!     var w: std.Io.Writer = .fixed(&buf);
//!     try toml.stringify(.{ .x = 1, .y = 2.5, .z = true }, .{}, &w);
//!     std.debug.print("{s}\n", .{w.buffered()});
//! }
//! ```
pub const tokenizer = @import("tokenizer.zig");
pub const parser = @import("parser.zig");
pub const stringify_mod = @import("stringify.zig");

const types = @import("../../types.zig");

pub const Value = types.Value;
pub const Error = types.Error;
pub const ParseOptions = types.ParseOptions;
pub const StringifyOptions = types.StringifyOptions;
pub const ObjectMap = types.ObjectMap;
pub const Array = types.Array;
pub const MAX_DEPTH = types.MAX_DEPTH;
pub const MAX_INPUT_BYTES = types.MAX_INPUT_BYTES;

pub const parseValue = parser.parseValue;
pub const parseFromSlice = parser.parseFromSlice;
pub const parseFree = parser.parseFree;
pub const parse = parser.parseFromSlice;
pub const stringify = stringify_mod.stringify;

pub const Stringifier = stringify_mod.Stringifier;

pub const Tokenizer = tokenizer.TomlTokenizer;
pub const TokenTag = tokenizer.TokenTag;
pub const Token = tokenizer.Token;

test {
    _ = tokenizer;
    _ = parser;
    _ = stringify_mod;
}
