const std = @import("std");
const testing = std.testing;
const ArenaAllocator = std.heap.ArenaAllocator;

const yaml = @import("../spec/yaml/root.zig");

test "yaml: parseValue simple scalar" {
    var arena = ArenaAllocator.init(testing.allocator);
    defer arena.deinit();
    var v = try yaml.parseValue(arena.allocator(), "hello");
    defer v.deinit();
    try testing.expectEqualStrings("hello", v.value.string);
}

test "yaml: parseValue integer" {
    var arena = ArenaAllocator.init(testing.allocator);
    defer arena.deinit();
    var v = try yaml.parseValue(arena.allocator(), "42");
    defer v.deinit();
    try testing.expectEqual(@as(i64, 42), v.value.integer);
}

test "yaml: parseValue boolean" {
    var arena = ArenaAllocator.init(testing.allocator);
    defer arena.deinit();
    var v = try yaml.parseValue(arena.allocator(), "true");
    defer v.deinit();
    try testing.expectEqual(true, v.value.bool);
}

test "yaml: parseValue null" {
    var arena = ArenaAllocator.init(testing.allocator);
    defer arena.deinit();
    var v = try yaml.parseValue(arena.allocator(), "null");
    defer v.deinit();
    try testing.expectEqual(.null, v.value);
}

test "yaml: parseValue flow mapping" {
    var arena = ArenaAllocator.init(testing.allocator);
    defer arena.deinit();
    var v = try yaml.parseValue(arena.allocator(), "{a: 1, b: 2}");
    defer v.deinit();
    try testing.expectEqual(@as(i64, 1), (v.value.object.get("a") orelse return error.TestFailed).integer);
}

test "yaml: parseValue flow sequence" {
    var arena = ArenaAllocator.init(testing.allocator);
    defer arena.deinit();
    var v = try yaml.parseValue(arena.allocator(), "[1, 2, 3]");
    defer v.deinit();
    try testing.expectEqual(@as(i64, 1), v.value.array.items[0].integer);
}

test "yaml: parseValue block mapping" {
    var arena = ArenaAllocator.init(testing.allocator);
    defer arena.deinit();
    var v = try yaml.parseValue(arena.allocator(),
        \\a: 1
        \\b: hello
    );
    defer v.deinit();
    try testing.expectEqual(@as(i64, 1), (v.value.object.get("a") orelse return error.TestFailed).integer);
    try testing.expectEqualStrings("hello", (v.value.object.get("b") orelse return error.TestFailed).string);
}

test "yaml: parseValue block sequence" {
    var arena = ArenaAllocator.init(testing.allocator);
    defer arena.deinit();
    var v = try yaml.parseValue(arena.allocator(),
        \\- 1
        \\- 2
        \\- 3
    );
    defer v.deinit();
    try testing.expectEqual(@as(i64, 1), v.value.array.items[0].integer);
    try testing.expectEqual(@as(i64, 2), v.value.array.items[1].integer);
}

test "yaml: parseValue nested block" {
    var arena = ArenaAllocator.init(testing.allocator);
    defer arena.deinit();
    var v = try yaml.parseValue(arena.allocator(),
        \\name: test
        \\items:
        \\  - 1
        \\  - 2
    );
    defer v.deinit();
    try testing.expectEqualStrings("test", (v.value.object.get("name") orelse return error.TestFailed).string);
    const items = (v.value.object.get("items") orelse return error.TestFailed).array;
    try testing.expectEqual(@as(i64, 1), items.items[0].integer);
    try testing.expectEqual(@as(i64, 2), items.items[1].integer);
}

test "yaml: parseValue quoted strings" {
    var arena = ArenaAllocator.init(testing.allocator);
    defer arena.deinit();
    var v = try yaml.parseValue(arena.allocator(), "'single quoted'");
    defer v.deinit();
    try testing.expectEqualStrings("single quoted", v.value.string);
}

test "yaml: parseFromSlice struct" {
    const S = struct { name: []const u8, count: u32 };
    var r = try yaml.parseFromSlice(S, testing.allocator,
        \\name: test
        \\count: 7
    , .{});
    defer r.deinit();
    try testing.expectEqualStrings("test", r.value.name);
    try testing.expectEqual(@as(u32, 7), r.value.count);
}

test "yaml: stringify roundtrip" {
    const S = struct { x: i32, y: f64 };
    const val = S{ .x = -3, .y = 1.5 };
    var buf: [256]u8 = undefined;
    var w: std.Io.Writer = .fixed(&buf);
    try yaml.stringify(val, .{}, &w);
    var back = try yaml.parseFromSlice(S, testing.allocator, w.buffered(), .{});
    defer back.deinit();
    try testing.expectEqual(val.x, back.value.x);
}

test "yaml: stringify Value" {
    var arena = ArenaAllocator.init(testing.allocator);
    defer arena.deinit();
    var v = try yaml.parseValue(arena.allocator(), "hello: world");
    defer v.deinit();
    var buf: [256]u8 = undefined;
    var w: std.Io.Writer = .fixed(&buf);
    try yaml.stringify(v.value, .{}, &w);
    var back = try yaml.parseValue(arena.allocator(), w.buffered());
    defer back.deinit();
    try testing.expectEqualStrings("world", (back.value.object.get("hello") orelse return error.TestFailed).string);
}

test "yaml: comments" {
    var arena = ArenaAllocator.init(testing.allocator);
    defer arena.deinit();
    var v = try yaml.parseValue(arena.allocator(),
        \\# this is a comment
        \\key: value
        \\# another comment
    );
    defer v.deinit();
    try testing.expectEqualStrings("value", (v.value.object.get("key") orelse return error.TestFailed).string);
}
